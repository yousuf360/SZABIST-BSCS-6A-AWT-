package edu.spring.hibernate.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.spring.hibernate.bean.Offeredcourse;
import edu.spring.hibernate.bean.Schedule;
import edu.spring.hibernate.bean.Sectiondetails;
import edu.spring.hibernate.bean.Vschedule;

@Service
@Transactional
public class ScheduleService extends BaseService
{
	public HashMap<String, Schedule> ListByCampus()
	{
		String key, pkey = null;
		HashMap<String, Schedule> hSchedule = new HashMap<String, Schedule>();
		List<Offeredcourse> offcrs = getSession().createQuery("from Offeredcourse where offid IN (select offid from Sectiondetails  WHERE secid IN (select secid from Section where sectionname LIKE  'MBA%E)%' ORDER BY sectionname))").list();
		
		List<Schedule> alSch = new ArrayList<Schedule>();
		for (Offeredcourse offeredcourse : offcrs) {
		 	alSch.addAll(offeredcourse.getSchedule());
		}
		
		for (Schedule schedule : alSch) {
			int secid = ((Sectiondetails) getSession()
					.createQuery(" from Sectiondetails where offid="+schedule
					.getOfferdcourse()
					.getOffid())
					.list()
					.get(0)).getSecid();
			
			key=schedule.getSlot().getDayid()
					+"-"+schedule.getSlot().getSlottypeid()
					+"-"+secid;
			
		hSchedule.put(key, schedule);
		
		}
		return hSchedule;
	}
	
	
}
